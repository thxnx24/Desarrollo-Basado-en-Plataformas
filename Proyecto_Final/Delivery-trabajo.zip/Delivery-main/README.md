# **DESCRIPCIÓN DEL PROYECTO**
## Practica xaml con xamarin forms
###### RESUMEN DEL PROYECTO
![]( https://i.ibb.co/p6Thqws/erew.png)

#### SÍGUENOS EN NUESTRAS REDES SOCIALES
> [YouTube](https://www.youtube.com/c/Codigo369 "YouTube")
[Facebook](https://www.faceboo "Facebook")
[Instagram](https://www.instagram.com/codigo369/ "Instagram")

###### Autor: Ing. Franklin J. Bustamante Alejandria
##### Pagina web: [codigo369.com](https://codigo369.com/ "codigo369.com")
> # “CUALQUIERA PUEDE PROGRAMAR”
